using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Shared.SeedWork;
using MongoDB.Driver ; 
namespace Infrastructure.Extensions
{
    public static class MongoCollectionExtension
    {
        public static async Task<PageList<T>> PaginatedListAsync<T>
        (this IMongoCollection<T> colection , FilterDefinition<T> filter , int currentPage , int pageSize)
        where T : class 
        {
            var items = await colection.Find(filter)
                        .Skip((currentPage - 1) * pageSize)
                        .Limit(pageSize).ToListAsync();
            var totalItems = colection.Find(filter).CountDocuments();
            return new PageList<T>(items , currentPage , pageSize ,(int)totalItems);
        }
    }
}