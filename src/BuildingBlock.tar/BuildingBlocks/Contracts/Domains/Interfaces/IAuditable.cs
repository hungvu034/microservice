using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Contracts.Domains
{
    public interface IAuditable : IDateTracking 
    {
        
    }
}