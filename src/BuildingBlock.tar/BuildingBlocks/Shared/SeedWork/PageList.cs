using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shared.SeedWork
{
    public class PageList<T> : List<T> 
    {
        public PageList(IEnumerable<T> items, int currentPage , int pageSize , int totalItems){
            _metaData = new MetaData(){
                CurrentPage = currentPage , 
                PageSize = pageSize ,
                TotalItems = totalItems 
            };
            AddRange(items);
        }
        private MetaData _metaData ; 
        public MetaData MetaData{
            get => _metaData ; 
        }
    }
}