namespace Shared.SeedWork ; 

public class RequestParameter{
    public string OrderBy { get; set; }
    public string SearchTerm { get; set; }
}