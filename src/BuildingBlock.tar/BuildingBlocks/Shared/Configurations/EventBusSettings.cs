using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shared.Configurations
{
    public class EventBusSettings
    {
        public string HostAddress { get; set; }
    }
}